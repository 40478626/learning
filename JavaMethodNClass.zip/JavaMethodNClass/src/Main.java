public class Main {

    public static void main(String[] args) {
        AccessMethodsWithObject myWorks = new AccessMethodsWithObject();
        myWorks.feedingCats();
        AccessMethodsWithObject.workingAtCompany(8);
    }

}