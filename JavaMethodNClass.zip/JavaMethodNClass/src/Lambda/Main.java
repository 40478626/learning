package Lambda;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<Integer> num = new ArrayList<Integer>();
        num.add(1);
        num.add(2);
        num.add(3);
        num.forEach((n) ->{System.out.println(n);});
    }
}
