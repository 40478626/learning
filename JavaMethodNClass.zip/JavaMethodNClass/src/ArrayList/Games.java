package ArrayList;

import java.util.ArrayList;

public class Games {
    public static void main(String[] args) {
        ArrayList<String> Games = new ArrayList<String>();
        Games.add("Valorant");
        Games.add("Dota2");
        Games.add("Overwatch2");
        Games.add("GTA 5");
        Games.add("A");
        Games.set(1,"Dota");
        Games.remove(4);
        //Games.clear();
        System.out.println(Games);
        System.out.println(Games.get(1));
        System.out.println(Games.size());

        for (int i = 0; i < Games.size(); i++){
            System.out.println(Games.get(i));
        }
    }
}
