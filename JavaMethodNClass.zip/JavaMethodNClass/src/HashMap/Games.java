package HashMap;

import java.util.HashMap;

public class Games {
    public static void main(String[] args) {
        HashMap<String,String> games = new HashMap<String, String>();
        games.put("ML","Mobile");
        games.put("Valorant","PC");
        games.put("Wild Rift", "Mobile");
        games.put("LOL","PC");
        games.put("A","A");
        games.remove("A");
        System.out.println(games);
        System.out.println(games.size());

        //print keys
        for (String i : games.keySet()) {
            System.out.println(i);
        }

        // Print values
        for (String i : games.values()) {
            System.out.println(i);
        }

        // Print keys and values
        for (String i : games.keySet()) {
            System.out.println("key: " + i + " value: " + games.get(i));
        }

    }
}
