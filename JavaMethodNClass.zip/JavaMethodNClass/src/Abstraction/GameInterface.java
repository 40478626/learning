package Abstraction;

abstract class GamePlatform {
    public abstract void runTheGame();
    public void endTheGame(){
        System.out.println("Exit the Game!");
    }
}
class Valorant extends GamePlatform{

    @Override
    public void runTheGame() {
        System.out.println("Entering the Volorant!");
    }
}

class Main{
    public static void main(String[] args) {
        //Cant create GamePlatform object
        Valorant valorant = new Valorant();
        valorant.runTheGame();
        valorant.endTheGame();
    }
}
