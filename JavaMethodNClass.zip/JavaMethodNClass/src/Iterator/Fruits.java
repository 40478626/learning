package Iterator;

import java.util.ArrayList;
import java.util.Iterator;

public class Fruits {
    public static void main(String[] args) {
        ArrayList<String> fruits = new ArrayList<>();
        fruits.add("Apple");
        fruits.add("Orange");
        fruits.add("Pineapple");
        fruits.add("Grapes");

        Iterator<String> Fruits = fruits.iterator();


        while (Fruits.hasNext()){
            System.out.println(Fruits.next());
        }
    }
}
