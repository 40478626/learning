package Iterator;

import java.util.ArrayList;
import java.util.Iterator;

public class numbers {
    public static void main(String[] args) {
        ArrayList<Integer> num = new ArrayList<Integer>();
        num.add(1);
        num.add(10);
        num.add(11);
        num.add(7);
        Iterator<Integer> Num = num.iterator();
        while (Num.hasNext()) {
            Integer i = Num.next();
            if (i < 5) {
                Num.remove();
            }
        }
            System.out.println(num);
    }
}
