package UserInput;

import java.util.Scanner;

public class newlineScanner {
    public static void main(String[] args) {
        Scanner scannerObj = new Scanner(System.in);
        String Username;

        System.out.println("Enter username : ");
        Username = scannerObj.nextLine();

        System.out.println("Username is " + Username + ".");
    }
}
