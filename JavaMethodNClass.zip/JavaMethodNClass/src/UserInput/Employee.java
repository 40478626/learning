package UserInput;
import java.util.Scanner;

public class Employee {
    public static void main(String[] args) {
        Scanner employee = new Scanner(System.in);

        String Name;
        int Age;
        Double salary;

        System.out.println("Enter Name, Age, Salary:");

        Name = employee.nextLine();
        Age = employee.nextInt();
        salary = employee.nextDouble();

        System.out.println("Name : " + Name);
        System.out.println("Age : "+ Age);
        System.out.println("Salary : " + salary);
    }
}
