package UserInput;

import java.util.Scanner;

public class Login {
    public static void main(String[] args) {
        Scanner login = new Scanner(System.in);
        String username;
        String password;

        System.out.println("Enter Username & Password : ");

        username = login.nextLine();
        password = login.nextLine();

        System.out.println("Username : " + username);

        System.out.println("Password : " + password);

    }
}
