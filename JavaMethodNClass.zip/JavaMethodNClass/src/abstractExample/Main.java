package abstractExample;

abstract class Main{
    String name = "Amara";
    int age = 22 ;
    public abstract void study();
}

class Student extends Main{
    int graduatedYear = 2021;

    @Override
    public void study() {
        System.out.println("Gaming 24/7!");
    }
}