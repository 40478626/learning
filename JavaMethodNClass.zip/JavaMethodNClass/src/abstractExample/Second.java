package abstractExample;

class Second{
    public static void main(String[] args) {
        Student student = new Student();
        System.out.println("Name : " + student.name);
        System.out.println("Age : " + student.age);
        System.out.println("Graduated Year : " + student.graduatedYear);
        student.study();

    }
}