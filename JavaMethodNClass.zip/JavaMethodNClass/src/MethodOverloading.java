public class MethodOverloading {
    public static int add(int x, int y){
        return x + y;
    }
    public static double add(double x, double y){
        return x + y;
    }

    public static void main(String[] args) {
        int x = add(3 ,5);
        double z = add(0.1, 0.2);
        System.out.println("int :" + x);
        System.out.println("double :" + z);
    }
}
