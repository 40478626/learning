package Enums;

public class Main {
    public static void main(String[] args) {
        Animals mydog = Animals.DOG;
        Animals mycat = Animals.CAT;
        //with Switch Statement
        switch (mycat){
            case CAT -> System.out.println("I have cat.");
            case DOG -> System.out.println("I have dog.");
            case DUCK -> System.out.println("I have duck.");
            case RABBIT -> System.out.println("I have rabbit.");
        }
        //In Loop Enum

        for (Animals animals: Animals.values()){
            System.out.println(animals);
        }

    }
}
