package Enums;

public enum Animals {
    //must be UpperCase
    CAT, DOG, DUCK, RABBIT
}

