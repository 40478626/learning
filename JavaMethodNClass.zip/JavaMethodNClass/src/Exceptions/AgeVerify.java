package Exceptions;

public class AgeVerify {
    public static void VeridicationOfAge(int age){
        if (age > 18){
            System.out.println("Age Verified!");
        }
        else {
            throw new ArithmeticException("Access Denied! You are underage!");
            }
    }

    public static void main(String[] args) {
        VeridicationOfAge(14);
    }
}
