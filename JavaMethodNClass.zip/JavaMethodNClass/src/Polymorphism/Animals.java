package Polymorphism;

public class Animals {
    public void animalsVoice(){
        System.out.println("Animals make sounds");
    }
}

class Cat extends Animals {
    public void animalsVoice(){
        System.out.println("Cats say Meow Meow!");
    }
}

class Dog extends Animals {
    public void animalsVoice(){
        System.out.println("Dogs say Woof Woof!");
    }
}

class Duck extends Animals{
    public void animalsVoice(){
        System.out.println("Ducks say Quck Quck!");
    }
}

class Main{
    public static void main(String[] args) {
        Animals animals = new Animals();
        animals.animalsVoice();
        Dog dog = new Dog();
        dog.animalsVoice();
        Cat cat = new Cat();
        cat.animalsVoice();
        Duck duck = new Duck();
        duck.animalsVoice();
    }
}