package Howto;

import java.util.Scanner;

public class Sum {
    public static void main(String[] args) {
        int x ,y, sum;
        Scanner num = new Scanner(System.in);
        System.out.println("Type first num : ");
        x = num.nextInt();


        System.out.println("Type Second Num : ");
        y = num.nextInt();

        sum = x + y;
        System.out.println("Sum = " + sum);
    }
}
