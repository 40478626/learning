package Interface.MultipleInterface;

interface EnterGame {
    public void runTheGame();
}
interface EndGame {
    public void endTheGame();
}

class Valorant implements EnterGame,EndGame{

    @Override
    public void runTheGame() {
        System.out.println("Entering Valorant");
    }

    @Override
    public void endTheGame() {
        System.out.println("Exiting Valorant");
    }
}

class Main{
    public static void main(String[] args) {
        Valorant valorant = new Valorant();
        valorant.runTheGame();
        valorant.endTheGame();
    }
}