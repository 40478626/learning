package Interface;

interface GamePlatform {
    public void runTheGame();
    public void endTheGame();
}

class Valorant implements GamePlatform{

    @Override
    public void runTheGame() {
        System.out.println("Entering Valorant!");
    }

    @Override
    public void endTheGame() {
        System.out.println("Exit Valorant!");
    }
}

class Main{
    public static void main(String[] args) {
        Valorant valorant = new Valorant();
        valorant.runTheGame();
        valorant.endTheGame();
    }
}