package DateAndTime;

import java.time.LocalDateTime;

public class DisplayCurrentDateAndTime {
    public static void main(String[] args) {
        LocalDateTime dateTime = LocalDateTime.now();
        System.out.println(dateTime);
    }
}
