package DateAndTime;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class FormatDateTime {
    public static void main(String[] args) {
        //to show local date and time
        LocalDateTime dateTime = LocalDateTime.now();

        //format the date and time
        DateTimeFormatter formatDateTime = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");

        //chg to string and format dateTime with formatDateTime
        String formattedData = dateTime.format(formatDateTime);

        System.out.println("Formatted Data : " + formattedData);
    }
}
