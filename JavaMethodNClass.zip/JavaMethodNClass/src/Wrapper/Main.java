package Wrapper;

public class Main {
    public static void main(String[] args) {
        Integer num = 3;
        String name = "Kiki";
        Double mydouble= 2.22;
        System.out.println(num);
        System.out.println(name);
        System.out.println(mydouble);
        String checknum = num.toString();
        System.out.println(checknum.length());

    }
}