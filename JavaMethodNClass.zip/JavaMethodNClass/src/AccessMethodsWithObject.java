public class AccessMethodsWithObject {
    public void feedingCats(){
        System.out.println("I feed 5 cats at home!");
    }
    public static void workingAtCompany (int workhours){
        System.out.println("I work at Company for "+ workhours + " hours!" );
    }

}
