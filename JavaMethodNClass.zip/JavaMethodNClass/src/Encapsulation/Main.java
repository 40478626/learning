package Encapsulation;

public class Main {
    public static void main(String[] args) {
        Student student = new Student();
        student.setName("Amara");
        System.out.println("Name : " + student.getName());
        student.setAge(22);
        System.out.println("Age : " + student.getAge());
    }
}
