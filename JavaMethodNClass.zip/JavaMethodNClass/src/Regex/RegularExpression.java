package Regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularExpression {
    public static void main(String[] args) {
        Pattern pattern = Pattern.compile("love", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher("I hate Cat!");

        boolean matchFound = matcher.find();

        if (matchFound){
            System.out.println("Match Found");
        }
        else {
            System.out.println("not found");
        }
    }
}
