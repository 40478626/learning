package Linkedlist;

import java.util.LinkedList;

public class Games {
    public static void main(String[] args) {
        LinkedList<String> games = new LinkedList<String>();
        games.add("Valorant");
        games.add("Dota");
        games.add("LOL");
        System.out.println(games);
    }
}
