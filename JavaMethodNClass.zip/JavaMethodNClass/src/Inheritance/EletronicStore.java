package Inheritance;

public class EletronicStore {
    public void sellDevices(){
        System.out.println("Thanks for your shopping!");
    }
}

class Phone extends EletronicStore{
    public static void main(String[] args) {
        Phone phone = new Phone();
        phone.sellDevices();
    }
}
