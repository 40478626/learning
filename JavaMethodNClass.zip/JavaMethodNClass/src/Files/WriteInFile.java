package Files;

import java.io.FileWriter;
import java.io.IOException;

public class WriteInFile {
    public static void main(String[] args) {
        try {
            FileWriter file = new FileWriter("Amara.txt");
            file.write("Writing");
            file.close();
            System.out.println("Successfully");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
