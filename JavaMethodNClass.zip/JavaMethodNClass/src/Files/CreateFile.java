package Files;

import java.io.File;
import java.io.IOException;

public class CreateFile {
    public static void main(String[] args) {
        try {
            File afile = new File("Amara.txt");
            if (afile.createNewFile()){
                System.out.println("File created : " + afile.getName());
            }
            else {
                System.out.println("File already exist");
            }
        }
        catch (IOException e){
            System.out.println("error occurred.");
            e.printStackTrace();
        }
    }
}
